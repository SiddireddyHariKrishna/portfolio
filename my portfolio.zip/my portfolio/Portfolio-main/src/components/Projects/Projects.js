import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import ProjectCard from "./ProjectCards";
import Particle from "../Particle";
import leavemanagement from "../../Assets/Projects/p1.jpeg";
import facial from "../../Assets/Projects/p3.jpeg";
import Dashboard from "../../Assets/Projects/Dashboard.png";
import Data from "../../Assets/Projects/Data.png";
import IMAGE from "../../Assets/Projects/p2.jpeg";

function Projects() {
  return (
    <Container fluid className="project-section">
      <Particle />
      <Container>
        <h1 className="project-heading">
          My Recent <strong className="purple">Works </strong>
        </h1>
        <p style={{ color: "white" }}>
          Here are a few projects I've worked on recently.
        </p>
        <Row style={{ justifyContent: "center", paddingBottom: "10px" }}>
          <Col md={4} className="project-card">
          <ProjectCard
              imgPath={leavemanagement}
              isBlog={false}
              title="LEAVE MANAGEMENT SYSTEM"
              description="Certainly! Creating a leave management system using the MERN stack (MongoDB, Express.js, React, Node.js) can be a great project. Here's an outline of the components you might want to include in your system"
              demoLink="#"
            />
          </Col>

          <Col md={4} className="project-card">
            <ProjectCard
              imgPath={facial}
              isBlog={false}
              title="FACIAL RECOGNITION"
              description="Creating a facial recognition attendance system involves building a application that allows users to manage and organize their attendance. Below is an outline of how you can structure and implement a basic facial attendace system ."
              demoLink="#"
            />
          </Col>

          <Col md={4} className="project-card">
            <ProjectCard
              imgPath={IMAGE}
              isBlog={false}
              title="IMAGE COMPRESSION"
              description="Certainly! Developing a image compression involves integrating with a image to compressed image.And minimize the data storage."
              demoLink="#"              
            />
          </Col>

          <Col md={4} className="project-card">
            <ProjectCard
              imgPath={Data}
              isBlog={false}
              title="Data Visualization"
              description="Data Visualization is a powerful and insightful process that transforms raw data from databases into visually compelling representations. Through a variety of visualization techniques, complex datasets are presented in a way that is easy to understand, facilitating analysis, decision-making, and the identification of patterns or trends"
              ghLink="https://github.com/prasanna-chintamaneni/KIET-RCTS-TASK1"
              demoLink="https://prasanna-kiet-rcts-task-1.vercel.app/"
            />
          </Col>

          <Col md={4} className="project-card">
            <ProjectCard
              imgPath={Dashboard}
              isBlog={false}
              title="Responsive Dashboard"
              description="This Responsive Dashboard is a web application built using React. It includes components like Navbar, Sidebar, Cards, PieCharts, Table, Form, and Footer. This project aims to provide a responsive and user-friendly interface for various functionalities"
              ghLink="https://github.com/prasanna-chintamaneni/KIET-RCTS-NOV-TASK"
              demoLink="https://nagaprasanna-kiet-rcts-nov-task.vercel.app/"
            />
          </Col>
        </Row>
      </Container>
    </Container>
  );
}
export default Projects;
